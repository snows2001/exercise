package com.example.mapping;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.mapping.manytoone.Student;
import com.example.mapping.manytoone.StudentRepository;
import com.example.mapping.manytoone.Teacher;
import com.example.mapping.manytoone.TeacherRepository;

import jakarta.transaction.Transactional;

@SpringBootTest
class ManyToOneMappingApplicationTests {
		
	@Autowired
	private TeacherRepository teacherRepository;
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Transactional
	@Test
	void contextLoads() {
		
		//선생님 1명 등록
		Teacher teacher = new Teacher();
		teacher.setName("쌤");
		teacherRepository.save(teacher);
		
		//학생 2명 등록
		Student s01 = new Student();
		s01.setName("용준님");
		s01.setTeacher(teacher);
		teacher.getStudents().add(s01);
		studentRepository.save(s01);
		
		Student s02 = new Student();
		s02.setName("민국님");
		s02.setTeacher(teacher);
		teacher.getStudents().add(s02);
		studentRepository.save(s02);		
		
		Assertions.assertThat(studentRepository.findById(1L).get().getTeacher().getName()).isEqualTo("쌤");
		Assertions.assertThat(teacherRepository.findById(1L).get().getStudents().size()).isEqualTo(2);
		
	}
	
}









