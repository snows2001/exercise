package com.example.mapping.manytoone;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class StudentDto {
	
	private Long id;
	private String name;
	
	public StudentDto(Student student) {
		this.id = student.getId();
		this.name = student.getName();
	}

}
