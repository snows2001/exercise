package com.example.mapping.manytoone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MappingController {

	@Autowired
	private StudentService studentService;
	
	@GetMapping("/{id}")
	public TeacherDto getTeacher(@PathVariable("id") Long id) throws NotFoundException {

		return studentService.getTeacherAndStudents(id);
	}
	
}
