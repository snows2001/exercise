package com.example.mapping.transaction;

import java.io.IOException;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;



@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AccountService {
	
	private final AccountRepository accountRepository;
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String transfer(TransferForm transferForm) {
		String message = "이체 실패";
		
		//보내는 사람 
		Optional<Account> _sender = accountRepository.findById(transferForm.getSender());
		
		//받는 사람
	    Optional<Account> _receiver = accountRepository.findById(transferForm.getReceiver());
		
	    
	    if(!_sender.isEmpty() && !_receiver.isEmpty()) {
	    	
	    	//보내는 사람의 잔액을 업데이트
	    	Account sender = _sender.get(); //계좌번호 1, 1000원
	    	sender.setBalance(sender.getBalance().subtract(transferForm.getMoney()));
	    	accountRepository.save(sender);
	    	
	    	
	    	//받는 사람의 잔액을 업데이트
	    	Account receiver = _receiver.get();
	    	receiver.setBalance(receiver.getBalance().add(transferForm.getMoney()));
	    	accountRepository.save(receiver);
	    	
	    	message = "이체 완료";
	    	    	
	    }	
		return message;
	}
	

}
