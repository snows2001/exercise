package com.example.mapping.transaction;

import java.math.BigInteger;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TransferForm {

	private Long sender;
	private Long receiver;
	private BigInteger money;
	
}
