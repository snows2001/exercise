package com.example.mapping.manytoone;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TeacherDto {
	
	private Long id;
	private String name;
	private List<StudentDto> students;
	
	public TeacherDto(Teacher teacher, List<StudentDto> students) {
		this.id = teacher.getId();
		this.name = teacher.getName();
		this.students = students;
	}
	
}
