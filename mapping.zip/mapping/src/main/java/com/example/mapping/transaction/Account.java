package com.example.mapping.transaction;

import java.math.BigInteger;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
public class Account {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long accountNo;
	private BigInteger balance;
	
	public Account() {}
	
	public Account(BigInteger balance) {
		this.balance = balance;
	}
	
	public Account(Long accountNo, BigInteger balance) {
		this.accountNo = accountNo;
		this.balance = balance;
	}	

}
